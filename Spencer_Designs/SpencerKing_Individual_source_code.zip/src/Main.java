import java.io.File;

import java.io.FileNotFoundException;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.io.PrintStream;
//import java.io.FileNotFoundException;
import java.util.Scanner;

//   /home/student/Desktop/garage_5/test_cases/test0_instruction_demo.txt
public class Main 
{
	  public static void main(String[] args)
	  {
//	    System.out.println("Starting simulation");
	    EventQueue handler = new EventQueue();
	    
	    
	    
// List files	    
//		File folder = new File("/");
//		File[] listOfFiles = folder.listFiles();
//
//		for (int i = 0; i < listOfFiles.length; i++) {
//		  if (listOfFiles[i].isFile()) {
//		    System.out.println("File " + listOfFiles[i].getName());
//		  } else if (listOfFiles[i].isDirectory()) {
//		    System.out.println("Directory " + listOfFiles[i].getName());
//		  }
//		}		
			    
	    
	    
    	String file = args[0];
        // read the file
        try {
			readFile(file, handler);
		} catch (FileNotFoundException e) {
			System.out.println("File not found, exiting...");
			e.printStackTrace();
			
			// Exit with error
			System.exit(1);
		}
	    
	    
	    
//		switch(args[0]){
//	    case "-f" : 
////	        File file = new File(args[0]);
//	    	String file = args[1];
//	        // read the file
//	        try {
//				readFile(file, handler);
//			} catch (FileNotFoundException e) {
//				System.out.println("File not found, exiting...");
//				e.printStackTrace();
//				
//				// Exit with error
//				System.exit(1);
//			}
//	        break;
//	    default :
//		}
		
//		printSummary( handler );
		
		// Run the simulation based on the supplied file for 20 iterations
		runSimulation( handler );
		
	    System.out.println("Ending simulation");
	  }	
	  
	  
	  public static void readFile(String fileName, EventQueue handler) throws FileNotFoundException {
//		  System.out.println("Attempting to read file: " + fileName);
		    Scanner scanner = new Scanner(new File(fileName));
		    scanner.useDelimiter(",");
		    while(scanner.hasNextLine()){
		    	String line = scanner.nextLine();
		    	
		        String[] splitLine = line.split(",");

//		        for (int i = 0; i < split.length; i++) {
//		            if (split[i].equals("")) {
//		                split[i] = null;
//		            }
//		        }
		        
		        
		        // We can use lists but hashmaps are much faster
		        
		        switch( splitLine[0] ) {
		        case "add_bus":
//		        	System.out.println("Adding bus");
		        	// add_bus,<ID>,<Route>,<Location>,<Initial-Passengers>,<PassengerCapacity>,<Initial-Fuel>,<Fuel-Capacity>,<Speed>
		        	Bus new_bus = new Bus(Integer.valueOf(splitLine[1]), Integer.valueOf(splitLine[2]), Integer.valueOf(splitLine[3]), Integer.valueOf(splitLine[4]), Integer.valueOf(splitLine[5]), Integer.valueOf(splitLine[6]), Integer.valueOf(splitLine[7]), Integer.valueOf(splitLine[8]));
		        	handler.add_bus(new_bus);
		        	break;
		        	
		        case "add_event":
//		        	System.out.println("Adding event");
		        	// Integer time_rank, String event_type, Integer event_ID
		        	Event new_event = new Event(Integer.valueOf(splitLine[1]), String.valueOf(splitLine[2]), Integer.valueOf(splitLine[3]));
		        	handler.add_event(new_event);
		        	
		        	
		        	break;
		        	
		        case "add_route":
//		        	System.out.println("Adding route");
//		        	System.out.println(Arrays.toString(splitLine));
		        	
		        	Route new_route = new Route(Integer.valueOf(splitLine[1]), Integer.valueOf(splitLine[2]), String.valueOf(splitLine[3]));
		        	handler.add_route(new_route);
		        	
		        	break;
		        	
		        case "add_stop":
//		        	System.out.println("Adding stop");
//		        	System.out.println(Arrays.toString(splitLine));
		        	// public Stop(int ID, String name, Integer riders, Double latitude, Double longitude)
		        	Stop new_stop = new Stop(Integer.valueOf(splitLine[1]), String.valueOf(splitLine[2]), Integer.valueOf(splitLine[3]), Double.valueOf(splitLine[4]), Double.valueOf(splitLine[5]));
		        	handler.add_stop(new_stop);
		        	
		        	break;
		        	
		        	
		        	
		        	
		        case "add_depot":
//		        	System.out.println("Adding depot");
		        	break;
		        
		        case "extend_route":
//		        	System.out.println("Extending route " + splitLine[1]);
		        	Route route_to_extend = handler.get_route_by_ID(Integer.valueOf(splitLine[1]));
		        	Stop stop_to_add = handler.get_stop_by_ID(Integer.valueOf(splitLine[2]));
		        	
		        	if (route_to_extend == null || stop_to_add == null) {
		        		System.out.println("Error, stop or route doesn't exist " + splitLine[1] + "," + splitLine[2]);
		        		break;
		        	}

		        	
//		        	System.out.println("got route " + route_to_extend.getName());
//		        	System.out.println("got stop " + stop_to_add.getName());
		        	
		        	route_to_extend.extend_route(stop_to_add);
		        	break;
		        
		        }

//		        System.out.println(Arrays.toString(splitLine));		    	
		    	
		    }
		    scanner.close();
		}

	  
	  
	  
	  public static void printSummary(EventQueue handler) {
		System.out.println("---------------Summary------------");
		  for (Route route : handler.getRoutes() ) {
			  System.out.println("Found route: " + route.getName());
			  
			  for (Stop stop_on_route : route.getRoute_stops() ) {
				  System.out.println("Found stop " + route.getRoute_stops().indexOf(stop_on_route)  + " : " + stop_on_route.getName() + " on route: " + route.getName());
			  }
			  
		  }

		  for (Stop stop : handler.getStops() ) {
			  System.out.println("Found stop: " + stop.getName());
		  }		  
		  
		  for (Bus bus : handler.getBuses() ) {
			  System.out.println("Found bus: " + bus.getID());
		  }		  
		  

		  for (Event event : handler.getEvent_queue() ) {
			  System.out.println("Found event " + handler.getEvent_queue().indexOf(event)  + " [" + event.getTime_rank() + "] " + event.getEvent_type() + " " + event.getEvent_ID());
		  }		  		  
		  
		  
		  System.out.println(handler.getRoutes());
		  System.out.println(handler.getStops());
		  System.out.println(handler.getBuses());
		  System.out.println(handler.getEvent_queue());

	  }
	  

	  public static void runSimulation(EventQueue handler) {
//		  System.out.println("~~~~~~~~~~~~~~~~Starting runSimulation~~~~~~~~~~~~~~~~~~~~~");
//		  System.out.println("EventQueue " + handler.getEvent_queue() );
		  
		  Integer time = 0;
//		  Integer eventCounter = 0;
//		  Integer response = 0;
		  
		  while (true) {
			  // Calculate the next events to add to the queue
			  handler.schedule_events(time);			  
			  
			  // Clear the queue for the specified time
			  handler.check_queue_for_events(time);
			  time += 1;
//			  
//			if (time >= 60) {
//				System.out.println("200 Time Completed");
//				System.exit(0);
//			}			  
			  
		  }
		  
		  
		  
//		  while ( (response = handler.check_queue_for_event(time)) != 0 ) {
//			  System.out.println("Ran event at time " + response);
//		  }
		  	
		  
//		  return;
	  }



}


