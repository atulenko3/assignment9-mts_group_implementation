
public class Event {

	private Integer time_rank;
	private String event_type;
	private Integer event_ID;
	
	public Event() {
		this.time_rank = 0;
		this.event_type = "Error";
		this.event_ID = 0;
	}
	
	public Event(Integer time_rank, String event_type, Integer event_ID) {
		this.time_rank = Integer.valueOf(time_rank);
		this.event_type = String.valueOf(event_type);
		this.event_ID = Integer.valueOf(event_ID);
	}	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * @return the time_rank
	 */
	public Integer getTime_rank() {
		return time_rank;
	}
	/**
	 * @param time_rank the time_rank to set
	 */
	public void setTime_rank(Integer time_rank) {
		this.time_rank = time_rank;
	}
	/**
	 * @return the event_type
	 */
	public String getEvent_type() {
		return event_type;
	}
	/**
	 * @param event_type the event_type to set
	 */
	public void setEvent_type(String event_type) {
		this.event_type = event_type;
	}
	/**
	 * @return the event_ID
	 */
	public Integer getEvent_ID() {
		return event_ID;
	}
	/**
	 * @param event_ID the event_ID to set
	 */
	public void setEvent_ID(Integer event_ID) {
		this.event_ID = event_ID;
	}
	
		
	
	
}
