
public class Stop {

	// Attributes for stop as a whole
	private Integer ID;
	private String name;
	private Double latitude;
	private Double longitude;
	private Integer riders;
	private Integer passenger_exfil_parameters[]; 
	private Integer passenger_infull_parameters[];
	private String type;
	
	
	// We don't technically need this. If we omit it then java automatically creates a default constructor
	// but we can use it to indicate some type of error
	public Stop()
	{
		this.ID = Integer.valueOf(0);
		this.name = "Error";
		this.latitude = 0.0;
		this.longitude = 0.0;
		this.riders = 0;
//		this.passenger_exfil_parameters = [];
//		this.passenger_infull_parameters = [];
		this.type = "Error";
    }	
	
	// In my UML diagram this is add_stop but I changed it to match convention.
	// Do I need to use valueof() when assigning?
	//public Stop(int ID, String name, Double latitude, Double longitude, Integer riders, String type) {
	public Stop(int ID, String name, Integer riders, Double latitude, Double longitude) {
		this.ID = ID;
		this.name = name;
		this.latitude = latitude;
		this.longitude = longitude;
		this.riders = riders;
		//this.type = type;
	}

//	public void add_stop(int ID, String name, Integer riders, Double latitude, Double longitude) {
//		// Create new stop
//		Stop new_stop = new Stop(ID, name, riders, latitude, longitude);
//		
//		// Add to EventQueue array of stops
//		
//		return;
//	}
//	
	


	/**
	 * @return the iD
	 */
	public Integer getID() {
		return ID;
	}


	/**
	 * @param iD the iD to set
	 */
	public void setID(Integer iD) {
		ID = iD;
	}


	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}


	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * @return the latitude
	 */
	public Double getLatitude() {
		return latitude;
	}


	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}


	/**
	 * @return the longitude
	 */
	public Double getLongitude() {
		return longitude;
	}


	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}


	/**
	 * @return the riders
	 */
	public Integer getRiders() {
		return riders;
	}


	/**
	 * @param riders the riders to set
	 */
	public void setRiders(Integer riders) {
		this.riders = riders;
	}


	/**
	 * @return the passenger_exfil_parameters
	 */
	public Integer[] getPassenger_exfil_parameters() {
		return passenger_exfil_parameters;
	}


	/**
	 * @param passenger_exfil_parameters the passenger_exfil_parameters to set
	 */
	public void setPassenger_exfil_parameters(Integer[] passenger_exfil_parameters) {
		this.passenger_exfil_parameters = passenger_exfil_parameters;
	}


	/**
	 * @return the passenger_infull_parameters
	 */
	public Integer[] getPassenger_infull_parameters() {
		return passenger_infull_parameters;
	}


	/**
	 * @param passenger_infull_parameters the passenger_infull_parameters to set
	 */
	public void setPassenger_infull_parameters(Integer[] passenger_infull_parameters) {
		this.passenger_infull_parameters = passenger_infull_parameters;
	}


	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}


	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	
	
	
	
}
