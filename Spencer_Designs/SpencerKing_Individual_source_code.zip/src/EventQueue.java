import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class EventQueue {
	
//	private ArrayList<String> event_queue = new ArrayList<String>(); 
	private ArrayList<Bus> buses = new ArrayList<Bus>();
	private ArrayList<Stop> stops = new ArrayList<Stop>();
	private ArrayList<Route> routes = new ArrayList<Route>();
	private ArrayList<Event> event_queue = new ArrayList<Event>();
	private Integer eventCounter = 0;
	
//	public EventQueue() {
//	}
	

	public void add_stop(Stop new_stop) {
		stops.add(new_stop);
		
//		System.out.println("STOP ADDED!!!");
//		System.out.println(stops);
		return;
	}
	

	public void add_route(Route new_route) {
		routes.add(new_route);
		
//		System.out.println("route ADDED!!!");
//		System.out.println(routes);
		return;
	}


	public void add_bus(Bus new_bus) {
		buses.add(new_bus);
		
//		System.out.println("bus ADDED!!!");
//		System.out.println(routes);
		return;
	}	

	public void add_event(Event new_event) {
		event_queue.add(new_event);
		
		
		Collections.sort(event_queue, new Comparator<Event>(){
		     public int compare(Event o1, Event o2){
		         if(o1.getTime_rank() == o2.getTime_rank())
		             return 0;
		         return o1.getTime_rank() < o2.getTime_rank() ? -1 : 1;
		     }
		});		
		
		
		
//		System.out.println("Event ADDED!!!");
//		System.out.println(event_queue);
		return;
	}		
	
	
	// Use this function to schedule
	public void schedule_events(Integer time) {
//		System.out.println("~~~~~~~~~~~~~~~~~Scheduler [" + time + "]~~~~~~~~~~~~~~");
		ArrayList<Bus> buses_to_move = new ArrayList<Bus>();
		
		for ( Bus bus : this.buses ) {
			// Only want buses who have already arrived somewhere at least once 
			// (buses must be started manually using the move_bus command to start)
//			System.out.println("BUS SUMMARY>> " + bus.getArrivalTime() + ", " + time);
			if ( bus.getArrivalTime() > 0 && bus.getArrivalTime() <= time ) {
				bus.setArrivalTime(time + calculate_distance_betweeen_stops(bus));
//				calculate_distance_betweeen_stops(bus);
				buses_to_move.add(bus);
			}
		}

		
//		System.out.println("Buses before sort" +  buses_to_move );
		
		if (buses_to_move.size() > 0 ) {
			Collections.sort(buses_to_move, new Comparator<Bus>(){
			     public int compare(Bus o1, Bus o2){
			         if(o1.getArrivalTime() == o2.getArrivalTime())
			             return 0;
			         return o1.getArrivalTime() < o2.getArrivalTime() ? -1 : 1;
			     }
			});			
		}

//		System.out.println("Buses after sort" +  buses_to_move );
		
//		System.out.println("Before adding>>" + this.event_queue);
		// Add move_bus commands to queue
		for ( Bus bus_event : buses_to_move ) {
			this.add_event(new Event(time, "move_bus", bus_event.getID()));
		}
//		System.out.println("After adding>>" + this.event_queue);
//		for (Event ev : event_queue) {
//			System.out.println("TS:" + ev.getTime_rank());
//		}
		
		
		
		return;
	}	
	
	
	
	
	// Use this function to calculate
	public Integer calculate_distance_betweeen_stops(Bus bus) {
//		System.out.println("Calculate");
		
//		System.out.println("Bus " + bus.getID() + " at location " + bus.getLocation() + " of route " 
//		+ bus.getRoute());
		
		// Get route by ID
//		System.out.println("route " + get_route_by_ID(bus.getRoute()));
//		System.out.println("stops " + get_route_by_ID(bus.getRoute()).getRoute_stops());
		
		Stop stop1 =  get_route_by_ID(bus.getRoute()).getRoute_stops().get(bus.getLocation());
		
//		System.out.println("array : " + get_route_by_ID(bus.getRoute()).getRoute_stops());
//		System.out.println("array length: " + get_route_by_ID(bus.getRoute()).getRoute_stops().size());
		
		// Bus is at end of the line, reset to zero
		Stop stop2;
		if ( bus.getLocation() + 1 ==  get_route_by_ID(bus.getRoute()).getRoute_stops().size()) {
//			System.out.println("Bus at end of line, location: " + bus.getLocation());
			stop2 =  get_route_by_ID(bus.getRoute()).getRoute_stops().get(0);
		} else {
			stop2 =  get_route_by_ID(bus.getRoute()).getRoute_stops().get(bus.getLocation() + 1);
		}
		
//		System.out.println("-------------------CALCULATIONS-----------------------");
//		System.out.println("BusID " + bus.getID() );
//		System.out.println("stop1 [" + stop1.getID() + "]: " + stop1.getName() );		
//		System.out.println("stop2 [" + stop2.getID() + "]: " + stop2.getName() );
//
//		System.out.println("s1 lat  " + stop1.getLatitude());
//		System.out.println("s1 long " + stop1.getLongitude());
//		System.out.println("s2 lat  " + stop2.getLatitude());
//		System.out.println("s2 long " + stop2.getLongitude());		
		//double distance = 70.0 * Math.sqrt( Math.pow((stop1_lat - stop2_lat), 2) + Math.pow((stop1_long - stop2_long), 2))
		double distance = 70.0 * Math.sqrt( Math.pow((stop1.getLatitude() - stop2.getLatitude()), 2) + Math.pow((stop1.getLongitude() - stop2.getLongitude()), 2));
//		System.out.println("Distance: " + distance );
//		System.out.println("Speed: " + bus.getSpeed() );
		int travel_time = 1 + ( (int) distance * 60 / bus.getSpeed());
//		System.out.println("Time to dest: " + travel_time );
//		System.out.println("-------------------CALCULATIONS-----------------------");	
		
		
		return travel_time;
	}	
	
	
	
	
	// Use this function to empty the queue
	public void check_queue_for_events(Integer time) {
//		System.out.println("~~~~~~~~~~~~~~~~~CHECKING QUEUE [" + time + "]~~~~~~~~~~~~~~~~~~~~~~~");
		
		while ( this.event_queue.size() > 0 &&  this.event_queue.get(0).getTime_rank() <= time ) {
//			System.out.println("Timerank: " + this.event_queue.get(0).getTime_rank());
			Event current_event = this.event_queue.get(0);
			if ( current_event.getEvent_type().equals("move_bus") ) {
//				System.out.println("Found event in queue: move bus: " + current_event.getEvent_ID());
				
				// Find the bus by ID
				    for(Bus bus : this.buses) {
				        if(bus.getID().equals(current_event.getEvent_ID())) {
				            // Update the arrival time for this bus
//				        	System.out.println("Move bus" + bus.getID() );
//				        	System.out.println("Initial Arrival time: " + bus.getArrivalTime() + ", Location: " + bus.getLocation());
				        	bus.setArrivalTime( time + calculate_distance_betweeen_stops(bus));
//				        	System.out.println(get_route_by_ID(bus.getRoute()).getRoute_stops().size() );
//				        	System.out.println( (bus.getLocation() + 1) % get_route_by_ID(bus.getRoute()).getRoute_stops().size() );
				        	
				        	bus.setLocation((bus.getLocation() + 1) % get_route_by_ID(bus.getRoute()).getRoute_stops().size());
//				        	System.out.println("Updated Arrival time: " + bus.getArrivalTime() + ", Location: " + bus.getLocation());
				        	// b:67->s:5@12//p:0/f:0
				        	System.out.println("b:" + bus.getID() + "->s:"
				        	+ get_route_by_ID(bus.getRoute()).getRoute_stops().get(bus.getLocation()).getID()
				        	+ "@" + bus.getArrivalTime() + "//p:0/f:0");
				        	// Update the position index of the bus
				        	
				        	// bus.setArrivalTime(arrivalTime);
				        }
				    }		
				
//				System.out.println("EventQueue Before" + this.getEvent_queue() + ", CTR:" + eventCounter );
				this.event_queue.remove(0);
				eventCounter += 1;
				if (eventCounter >= 20) {
//					System.out.println("20 Events Completed");
					System.exit(0);
				}
//				System.out.println("EventQueue After" + this.getEvent_queue() + ", CTR:" + eventCounter );
			}		
		}
		return;
	}	
	
	
	
	
	
	
	
	
	public Route get_route_by_ID(Integer route_ID) {
//		System.out.println("Getting route ID: " + route_ID);
//		java.util.ArrayList.IndexOf()
		
	    for(Route extending : routes) {
	        if(extending.getID().equals(route_ID)) {
//	        	System.out.println("Found route in route list");
	            return extending;
	        }
	    }
	    return null;		
		
	}		
	
	
	public Stop get_stop_by_ID(Integer stop_ID) {
//		System.out.println("Getting route ID: " + stop_ID);
//		java.util.ArrayList.IndexOf()
		
	    for(Stop extending : stops) {
	        if(extending.getID().equals(stop_ID)) {
//	        	System.out.println("Found stop " + stop_ID + " in route list");
	            return extending;
	        }
	    }
	    return null;		
		
	}


	/**
	 * @return the buses
	 */
	public ArrayList<Bus> getBuses() {
		return buses;
	}


	/**
	 * @param buses the buses to set
	 */
	public void setBuses(ArrayList<Bus> buses) {
		this.buses = buses;
	}


	/**
	 * @return the stops
	 */
	public ArrayList<Stop> getStops() {
		return stops;
	}


	/**
	 * @param stops the stops to set
	 */
	public void setStops(ArrayList<Stop> stops) {
		this.stops = stops;
	}


	/**
	 * @return the routes
	 */
	public ArrayList<Route> getRoutes() {
		return routes;
	}


	/**
	 * @param routes the routes to set
	 */
	public void setRoutes(ArrayList<Route> routes) {
		this.routes = routes;
	}


	/**
	 * @return the event_queue
	 */
	public ArrayList<Event> getEvent_queue() {
		return event_queue;
	}


	/**
	 * @param event_queue the event_queue to set
	 */
	public void setEvent_queue(ArrayList<Event> event_queue) {
		this.event_queue = event_queue;
	}			
	
	
	
	

}
