
public class Bus {

	private Integer ID;
	private Integer route;
	private Integer route_index;
	private Integer location;
	private Integer number_of_riders = 0;
	private Integer capacity;
	private Integer speed; // Should I change speed to Integer to match P2 spec?
	private Double estimated_trip_time;
	private Integer stops_travelled = 0;
	private Boolean engine_running = false;
	private Boolean is_stopped;
	private Integer time_stopped = 0;
	private Integer distance_to_next_stop;
//	private Double fuel; // Deprecated
//	private Double max_fuel_distance; // Deprecated

	// Not in UML
	private Integer fuel;
	private Integer fuel_capacity;
	private Integer arrivalTime = -1;
	
	public Bus() {
		this.ID = Integer.valueOf(0);
	}
// add_bus,<ID>,<Route>,<Location>,<Initial-Passengers>,<PassengerCapacity>,<Initial-Fuel>,<Fuel-Capacity>,<Speed>	
	public Bus(Integer ID, Integer route, Integer location, Integer initialPassengers, Integer passengerCapacity, Integer initialFuel, Integer fuelCapacity, Integer initialSpeed ) {
		this.ID = ID;
		this.route = route;
		this.location = location;
		this.number_of_riders = initialPassengers;
		this.capacity = passengerCapacity;
		this.fuel = initialFuel;
		this.fuel_capacity = fuelCapacity;
		this.speed = initialSpeed;
		this.is_stopped = true;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * @return the iD
	 */
	public Integer getID() {
		return ID;
	}
	/**
	 * @param iD the iD to set
	 */
	public void setID(Integer iD) {
		ID = iD;
	}
	/**
	 * @return the route
	 */
	public Integer getRoute() {
		return route;
	}
	/**
	 * @param route the route to set
	 */
	public void setRoute(Integer route) {
		this.route = route;
	}
	/**
	 * @return the route_index
	 */
	public Integer getRoute_index() {
		return route_index;
	}
	/**
	 * @param route_index the route_index to set
	 */
	public void setRoute_index(Integer route_index) {
		this.route_index = route_index;
	}
	/**
	 * @return the location
	 */
	public Integer getLocation() {
		return location;
	}
	/**
	 * @param location the location to set
	 */
	public void setLocation(Integer location) {
		this.location = location;
	}
	/**
	 * @return the number_of_riders
	 */
	public Integer getNumber_of_riders() {
		return number_of_riders;
	}
	/**
	 * @param number_of_riders the number_of_riders to set
	 */
	public void setNumber_of_riders(Integer number_of_riders) {
		this.number_of_riders = number_of_riders;
	}
	/**
	 * @return the capacity
	 */
	public Integer getCapacity() {
		return capacity;
	}
	/**
	 * @param capacity the capacity to set
	 */
	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}
	/**
	 * @return the speed
	 */
	public Integer getSpeed() {
		return speed;
	}
	/**
	 * @param speed the speed to set
	 */
	public void setSpeed(Integer speed) {
		this.speed = speed;
	}
	/**
	 * @return the estimated_trip_time
	 */
	public Double getEstimated_trip_time() {
		return estimated_trip_time;
	}
	/**
	 * @param estimated_trip_time the estimated_trip_time to set
	 */
	public void setEstimated_trip_time(Double estimated_trip_time) {
		this.estimated_trip_time = estimated_trip_time;
	}
	/**
	 * @return the stops_travelled
	 */
	public Integer getStops_travelled() {
		return stops_travelled;
	}
	/**
	 * @param stops_travelled the stops_travelled to set
	 */
	public void setStops_travelled(Integer stops_travelled) {
		this.stops_travelled = stops_travelled;
	}
	/**
	 * @return the engine_running
	 */
	public Boolean getEngine_running() {
		return engine_running;
	}
	/**
	 * @param engine_running the engine_running to set
	 */
	public void setEngine_running(Boolean engine_running) {
		this.engine_running = engine_running;
	}
	/**
	 * @return the is_stopped
	 */
	public Boolean getIs_stopped() {
		return is_stopped;
	}
	/**
	 * @param is_stopped the is_stopped to set
	 */
	public void setIs_stopped(Boolean is_stopped) {
		this.is_stopped = is_stopped;
	}
	/**
	 * @return the time_stopped
	 */
	public Integer getTime_stopped() {
		return time_stopped;
	}
	/**
	 * @param time_stopped the time_stopped to set
	 */
	public void setTime_stopped(Integer time_stopped) {
		this.time_stopped = time_stopped;
	}
	/**
	 * @return the distance_to_next_stop
	 */
	public Integer getDistance_to_next_stop() {
		return distance_to_next_stop;
	}
	/**
	 * @param distance_to_next_stop the distance_to_next_stop to set
	 */
	public void setDistance_to_next_stop(Integer distance_to_next_stop) {
		this.distance_to_next_stop = distance_to_next_stop;
	}
	/**
	 * @return the fuel
	 */
	public Integer getFuel() {
		return fuel;
	}
	/**
	 * @param fuel the fuel to set
	 */
	public void setFuel(Integer fuel) {
		this.fuel = fuel;
	}
	/**
	 * @return the fuel_capacity
	 */
	public Integer getFuel_capacity() {
		return fuel_capacity;
	}
	/**
	 * @param fuel_capacity the fuel_capacity to set
	 */
	public void setFuel_capacity(Integer fuel_capacity) {
		this.fuel_capacity = fuel_capacity;
	}
	/**
	 * @return the arrivalTime
	 */
	public Integer getArrivalTime() {
		return arrivalTime;
	}
	/**
	 * @param arrivalTime the arrivalTime to set
	 */
	public void setArrivalTime(Integer arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	
	
	
	
	
	
	
	
}
