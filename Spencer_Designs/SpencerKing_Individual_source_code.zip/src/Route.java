import java.util.ArrayList;

public class Route {
	
	private Integer ID;
	private Integer route_number;
	private String name;
//	private ArrayList<Integer> route_stops;
	private ArrayList<Stop> route_stops;
	
	
	public Route() {
		this.ID = 0;
		this.route_number = 0;
		this.name = "Error";
		this.route_stops = null; // Is this the right way to initialize the array?
	}
	
	// add_route,<ID>,<Number>,<Name>
	public Route(Integer ID, Integer route_number, String name) {
		this.ID = Integer.valueOf(ID);
		this.route_number = Integer.valueOf(route_number);
		this.name = String.valueOf(name);
//		this.route_stops = new ArrayList<Integer>();
		this.route_stops = new ArrayList<Stop>();
	}

	
	
	public void extend_route( Stop stop_to_add ) {
//		System.out.println("Adding stop " + stop_to_add.getName() + " to " + this.ID );
		route_stops.add(stop_to_add);
		return;
	}

	/**
	 * @return the iD
	 */
	public Integer getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setID(Integer iD) {
		ID = iD;
	}

	/**
	 * @return the route_number
	 */
	public Integer getRoute_number() {
		return route_number;
	}

	/**
	 * @param route_number the route_number to set
	 */
	public void setRoute_number(Integer route_number) {
		this.route_number = route_number;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the route_stops
	 */
	public ArrayList<Stop> getRoute_stops() {
		return route_stops;
	}

	/**
	 * @param route_stops the route_stops to set
	 */
	public void setRoute_stops(ArrayList<Stop> route_stops) {
		this.route_stops = route_stops;
	}
	
	

}
