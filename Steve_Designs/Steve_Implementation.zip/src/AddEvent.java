public class AddEvent {
    int logicalTime;
    String eventType;
    int objectId;
}
