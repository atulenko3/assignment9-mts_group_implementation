public class AddDepot {
    int depotId;
    String depotName;
    double xDepot_Longitude;
    double yDepot_Latitude;
}
