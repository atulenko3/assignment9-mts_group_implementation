public class AddRoute {
    int routeId;
    int routeNumber;
    String routeName;
}
