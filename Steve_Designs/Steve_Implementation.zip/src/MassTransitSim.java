import java.util.*;
import java.io.File;

public class MassTransitSim {
    public static void main(String[] args) {
        final String DELIMITER = ",";
        String file = args[0];

        List<AddDepot> depotList = new ArrayList<AddDepot>();
        List<AddStop> stopList = new ArrayList<AddStop>();
        List<AddRoute> routeList = new ArrayList<AddRoute>();
        List<ExtendRoute> extendRouteList = new ArrayList<ExtendRoute>();
        List<AddBus> busList = new ArrayList<AddBus>();
        List<AddEvent> eventList = new ArrayList<AddEvent>();

        try {
            Scanner takeCommand = new Scanner(new File(file));
            String[] tokens;
            do {
                String userCommandLine = takeCommand.nextLine();
                tokens = userCommandLine.split(DELIMITER);
                switch (tokens[0]) {
                    case "add_depot":
                        AddDepot depotInfo = new AddDepot();
                        depotInfo.depotId = Integer.parseInt(tokens[1]);
                        depotInfo.depotName = tokens[2];
                        depotInfo.xDepot_Longitude = Float.parseFloat(tokens[3]);
                        depotInfo.yDepot_Latitude = Float.parseFloat(tokens[4]);
                        depotList.add(depotInfo);
                        break;
                    case "add_stop":
                        AddStop stopInfo = new AddStop();
                        stopInfo.stopId = Integer.parseInt(tokens[1]);
                        stopInfo.stopName = tokens[2];
                        stopInfo.numOfRidersAtStop = Integer.parseInt(tokens[3]);
                        stopInfo.xStop_Longitude = Float.parseFloat(tokens[4]);
                        stopInfo.yStop_Latitude = Float.parseFloat(tokens[5]);
                        stopList.add(stopInfo);
                        break;
                    case "add_route":
                        AddRoute routeInfo = new AddRoute();
                        routeInfo.routeId = Integer.parseInt(tokens[1]);
                        routeInfo.routeNumber = Integer.parseInt(tokens[2]);
                        routeInfo.routeName = tokens[3];
                        routeList.add(routeInfo);
                        break;
                    case "extend_route":
                        ExtendRoute extendRouteInfo = new ExtendRoute();
                        extendRouteInfo.routeId = Integer.parseInt(tokens[1]);
                        extendRouteInfo.stopId = Integer.parseInt(tokens[2]);
                        extendRouteList.add(extendRouteInfo);
                        break;
                    case "add_bus":
                        AddBus  addBusInfo = new AddBus();
                        addBusInfo.busId = Integer.parseInt(tokens[1]);
                        addBusInfo.routeId = Integer.parseInt(tokens[2]);
                        addBusInfo.startingLocationId = Integer.parseInt(tokens[3]);
                        addBusInfo.numberOfPassengers = Integer.parseInt(tokens[4]);
                        addBusInfo.maxNumberOfPassengers = Integer.parseInt(tokens[5]);
                        addBusInfo.currentFuelValue = Integer.parseInt(tokens[6]);
                        addBusInfo.maxFuelValue = Integer.parseInt(tokens[7]);
                        addBusInfo.speed = Integer.parseInt(tokens[8]);
                        busList.add(addBusInfo);
                        break;
                    case "add_event":
                        AddEvent eventInfo = new AddEvent();
                        eventInfo.logicalTime = Integer.parseInt(tokens[1]);
                        eventInfo.eventType = tokens[2];
                        eventInfo.objectId = Integer.parseInt(tokens[3]);
                        eventList.add(eventInfo);
                        break;
                    default:
                        System.out.println(" command not recognized");
                        break;
                }
            } while (takeCommand.hasNextLine());

            takeCommand.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println();
        }

        List<String> busPrintOuts = new ArrayList<>();

        // create a list of bus routes with their stops
        List<BusRoutes> busRouteList = new ArrayList<BusRoutes>();
        for (int i = 0; i < routeList.size(); i++) {
            BusRoutes busRouteInfo = new BusRoutes();
            List<Integer> tempStopList = new ArrayList<>();
            busRouteInfo.routeId = routeList.get(i).routeId;
            for (int j = 0; j < extendRouteList.size(); j++) {
                if (extendRouteList.get(j).routeId == routeList.get(i).routeId) {
                    tempStopList.add(extendRouteList.get(j).stopId);
                }
            }
            busRouteInfo.busStopIDs = tempStopList;
            busRouteList.add(busRouteInfo);
        }

        while (busPrintOuts.size() < 20) {
            // creates a list of just move_bus events
            List<AddEvent> moveBusEvents = new ArrayList<AddEvent>();
            for (int i = 0; i < eventList.size(); i++) {
                if (eventList.get(i).eventType.equals("move_bus")) {
                    moveBusEvents.add(eventList.get(i));
                }
            }

            // if there are move_bus events than move some buses
            if (moveBusEvents.size() > 0) {
                // this sorts the list so that the lowest logical time is in spot [0]
                moveBusEvents.sort(Comparator.comparing(a -> a.logicalTime));
                int initialValue = moveBusEvents.get(0).logicalTime;
                List<AddEvent> lowestLogicalTimeEvents = new ArrayList<AddEvent>();

                // First: locate the lowest logical Time
                for (int i = 0; i < moveBusEvents.size(); i++) {
                    if (moveBusEvents.get(i).logicalTime == initialValue) {
                        lowestLogicalTimeEvents.add(moveBusEvents.get(i));
                    }
                }

                // get all bus values for these buses in busesToMove list
                List<AddBus> busesToMove = new ArrayList<AddBus>();
                for (int i = 0; i < lowestLogicalTimeEvents.size(); i++) {
                    int busId = lowestLogicalTimeEvents.get(i).objectId;
                    for (int j = 0; j < busList.size(); j++) {
                        if (busList.get(j).busId == busId) {
                            busesToMove.add(busList.get(j));
                        }
                    }
                }

                //    *********** GET THE BUS ROUTE INFORMATION FOR BUS  ***************
                //    *************************************************************************
                for (int i = 0; i < busesToMove.size(); i++) {
                    int busId = busesToMove.get(i).busId;
                    int busStartingLocation = busesToMove.get(i).startingLocationId;
                    int busRouteId = busesToMove.get(i).routeId;
                    int busSpeed = busesToMove.get(i).speed;
                    int finishingIdNumber = 0;
                    double startingXvalue = 0;
                    double startingYvalue = 0;
                    double finishingXvalue = 0;
                    double finishingYvalue = 0;

                    for (int j = 0; j < busRouteList.size(); j++) {
                        // here we have Bus and its Bus Route
                        int oldLogicalTime = 0;
                        if (busRouteList.get(j).routeId == busRouteId) {
                            int startingIdNumber = busRouteList.get(j).busStopIDs.get(busStartingLocation);
                            if (busStartingLocation + 1 < busRouteList.get(j).busStopIDs.size()) {
                                finishingIdNumber = busRouteList.get(j).busStopIDs.get(busStartingLocation + 1);
                            } else {
                                finishingIdNumber = busRouteList.get(j).busStopIDs.get(0);
                            }

                            // get x and y values for starting and finshing stops
                            for (int k = 0; k < stopList.size(); k++) {
                                if (startingIdNumber == stopList.get(k).stopId) {
                                    startingXvalue = stopList.get(k).xStop_Longitude;
                                    startingYvalue = stopList.get(k).yStop_Latitude;
                                }
                                if (finishingIdNumber == stopList.get(k).stopId) {
                                    finishingXvalue = stopList.get(k).xStop_Longitude;
                                    finishingYvalue = stopList.get(k).yStop_Latitude;
                                }
                            }
                            // calculate time value
                            double distanceBetweenStops = 70.0 * Math.sqrt(Math.pow((startingYvalue - finishingYvalue), 2) + Math.pow((startingXvalue - finishingXvalue), 2));
                            int distance = (int)distanceBetweenStops;

                            int travelTime = 1 + (distance * 60 / busSpeed);
                            //int travelTime = ((int)Math.round(distanceBetweenStops * 60 / busSpeed));
                            //int travelTime = ((int)(distanceBetweenStops * 60 / busSpeed));
                            for (int k=0; k < eventList.size(); k++){
                                if (eventList.get(k).objectId == busId){
                                    oldLogicalTime = eventList.get(k).logicalTime;
                                    break;
                                }
                            }

                            //int travel_time = ((int) Math.round(60 * (distanceBetweenStops) / busSpeed));
                            travelTime +=  oldLogicalTime;
                            busPrintOuts.add("b:" + busId + "->s:" + finishingIdNumber + "@" + travelTime + "//p:0/f:0");

                            // delete event
                            int removeIndexValue = 0;
                            for (int k = 0; k < eventList.size(); k++) {
                                if (eventList.get(k).objectId == busId) {
                                    removeIndexValue = k;
                                    break;
                                }
                            }
                            eventList.remove(removeIndexValue);

                            // add event
                            AddEvent eventInfo = new AddEvent();
                            eventInfo.logicalTime = (int)travelTime;
                            eventInfo.eventType = "move_bus";
                            eventInfo.objectId = busId;
                            eventList.add(eventInfo);

                            // update bus starting location
                            for (int k = 0; k < busList.size(); k++) {
                                int newStartingLocation = 0;
                                if (busList.get(k).busId == busId) {
                                    int routeId = busList.get(k).routeId;
                                    for (int m = 0; m < busRouteList.size(); m++) {
                                        if (busRouteList.get(m).routeId == routeId) {
                                            int numberOfStopsInRoute = busRouteList.get(m).busStopIDs.size();
                                            if (busStartingLocation + 1 < numberOfStopsInRoute) {
                                                newStartingLocation = busStartingLocation + 1;
                                            } else {
                                                newStartingLocation = 0;
                                            }
                                        }
                                    }
                                    busList.get(k).startingLocationId = newStartingLocation;
                                }
                            }
                        }
                    }
                }
            }
        }
        for (int i = 0; i < busPrintOuts.size(); i++) {
            System.out.println(busPrintOuts.get(i));
        }
    }
}

