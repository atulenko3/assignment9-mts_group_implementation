public class AddStop {
    int stopId;
    String stopName;
    int numOfRidersAtStop;
    double xStop_Longitude;
    double yStop_Latitude;
}
