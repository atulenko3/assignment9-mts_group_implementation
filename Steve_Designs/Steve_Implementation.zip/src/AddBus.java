public class AddBus {
    int busId;
    int routeId;
    int startingLocationId;
    int numberOfPassengers;
    int maxNumberOfPassengers;
    int currentFuelValue;
    int maxFuelValue;
    int speed;
}
