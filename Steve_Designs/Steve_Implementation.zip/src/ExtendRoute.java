public class ExtendRoute {
    int routeId;
    int stopId;
}
