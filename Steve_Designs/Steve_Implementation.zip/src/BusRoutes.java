import java.util.*;
public class BusRoutes {
    int routeId;
    List<Integer> busStopIDs;
}
