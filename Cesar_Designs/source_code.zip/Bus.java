public class Bus {
	private int id;
	private int route;
	private int nextLocation;
	private int previousLocation;
	private int passengers;
	private int passengerCapacity;
	private int averageSpeed;
	private int initialFuel;
	private int fuelCapacity;
	private int arrivalTime;
	
	
	public Bus(int id, int route, int location, int passengers, int passengerCapacity, int initialFuel, int fuelCapacity,int speed) {
		this.id = id;
		this.route = route;
		previousLocation = location;
		nextLocation = location;
		this.passengers = passengers;
		this.passengerCapacity = passengerCapacity;
		this.initialFuel = initialFuel;
		this.fuelCapacity = fuelCapacity;
		this.averageSpeed = speed;
		this.arrivalTime = 0;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRoute() {
		return route;
	}
	public void setRoute(int route) {
		this.route = route;
	}
	public int getLocation() {
		return nextLocation;
	}
	public void setLocation(int newLocation) {
		previousLocation = nextLocation;
		nextLocation = newLocation;
	}
	public int getPreviousLocation() {
		return previousLocation;
	}

	public int getPassengers() {
		return passengers;
	}
	public void setPassengers(int passengers) {
		this.passengers = passengers;
	}
	public int getPassengerCapacity() {
		return passengerCapacity;
	}
	public void setPassengerCapacity(int passengerCapacity) {
		this.passengerCapacity = passengerCapacity;
	}
	public int getAverageSpeed() {
		return averageSpeed;
	}
	public void setAverageSpeed(int averageSpeed) {
		this.averageSpeed = averageSpeed;
	}
	public int getInitialFuel() {
		return initialFuel;
	}
	public void setInitialFuel(int initialFuel) {
		this.initialFuel = initialFuel;
	}
	public int getFuelCapacity() {
		return fuelCapacity;
	}
	public void setFuelCapacity(int fuelCapacity) {
		this.fuelCapacity = fuelCapacity;
	}
	public int getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(int arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
}
