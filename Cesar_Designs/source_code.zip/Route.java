import java.util.HashMap;

public class Route {
	private int id;
	private int number;
	private String name;
	private HashMap<Integer,Integer> stops;
	
	public Route(int id, int number, String name) {
		this.id = id;
		this.number = number;
		this.name = name;
		stops = new HashMap<Integer,Integer>();
	}
		
	public void extendRoute(int stopId) {
		stops.put(Integer.valueOf(stops.size()), Integer.valueOf(stopId));
	}
	
	public Integer getNextLocation(int routeLocation) {
	    int routeSize = stops.size() - 1; //Return the last key in the hashmap
	    if (routeSize > 0 && routeLocation != routeSize) {
	    	return Integer.valueOf(routeLocation % routeSize + 1);
	    } return Integer.valueOf(0);
	  }
	
	public Integer getCurrentStop(int currentLocation) {
		return stops.get(Integer.valueOf(currentLocation));
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}

