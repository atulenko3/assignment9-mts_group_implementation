public class Stop {
	private int id;
	private String name;
	private int riders;
	private Double latitude;
	private Double longitude;
	
	
	public Stop(int id, String name, int riders, Double latitude, Double longitude) {
		this.id = id;
		this.name = name;
		this.riders = riders;
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRiders() {
		return riders;
	}
	public void setRiders(int riders) {
		this.riders = riders;
	}
	public Double getLatitude() {
		return latitude;
	}
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	
	public Double findDistance(Stop nextStop) {
		return Double.valueOf(70.0D * Math.sqrt(Math.pow(latitude.doubleValue() - nextStop.getLatitude().doubleValue(), 2.0D) + Math.pow(longitude.doubleValue() - nextStop.getLongitude().doubleValue(), 2.0D)));
	}
	
	public void addRiders(int arrivingRiders) {
		this.setRiders(arrivingRiders);
	}
}
