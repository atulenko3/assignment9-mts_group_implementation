import java.util.PriorityQueue;
import java.util.Comparator;

public class EventQueue {
	private static PriorityQueue<Event> eventQueue;
	private Comparator<Event> eventComparator;
	
	public EventQueue() {
		eventComparator = new EventComparator();
		eventQueue = new PriorityQueue<Event>(50, eventComparator);
	}
	
	public void triggerNextEvent(TransitSystem mts) {
		if (eventQueue.size() > 0) {
			Event activeEvent = eventQueue.poll();
			switch (activeEvent.getType()) {
			case "move_bus":
				Bus activeBus = mts.getBus(activeEvent.getId()); //Returns the bus that needs to be moved based on the activeEvent ID
				
				Route activeRoute = mts.getRoute(activeBus.getRoute()); //Returns the activeRoute the bus is on based on the route attribute of the bus object
				
				int activeLocation = activeBus.getLocation(); //Returns the current location of the bus along the route
				
				int activeStopId = activeRoute.getCurrentStop(activeLocation); //Based on the activeLocation on the route get the activeStopId
				Stop activeStop = mts.getStop(activeStopId); //Returns the stop object identified by activeStopId
				
				int nextLocation = activeRoute.getNextLocation(activeLocation); //Based on the activeLocation, returns the nextLocation's position on the route
				int nextStopId = activeRoute.getCurrentStop(nextLocation); //Based on the nextLocation on the route get the activeStopId
				Stop nextStop = mts.getStop(nextStopId); //Returns the stop object identified by nextStopId
				
				Double distanceBetweenStops = activeStop.findDistance(nextStop); //Calculates the distance between the activeStop and the nextStop
				int travelTime = 1 + (distanceBetweenStops.intValue() * 60) / activeBus.getAverageSpeed(); //Returns the travel time between stops 
				activeBus.setLocation(nextLocation); //"Moves" the bus to the next location on the route
				int nextArrivalTime = activeEvent.getTime() + travelTime; //Returns the logical time at which the bus will arrive at its next stop
				activeBus.setArrivalTime(nextArrivalTime); //Updates the arrivalTime attribute of the bus object
				eventQueue.add(new Event(nextArrivalTime, "move_bus", activeEvent.getId())); //Queue the next event for this bus that is to occur at the previously calculated logical time
				
				System.out.println("b:" + activeBus.getId() + "->s:" + nextStopId + "@" + activeBus.getArrivalTime() + "//p:0/f:0"); //Output summary to console for each event
				break;
			default:
				System.out.println("This is not valid event");
			}
		}
		else {
			System.out.println("The queue is empty");
		}
		
	}
	
	public void addEvent(int time, String type, int id) {
		eventQueue.add(new Event(time,type,id));
	}
}
