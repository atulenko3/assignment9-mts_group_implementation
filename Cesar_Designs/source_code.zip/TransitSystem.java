import java.util.HashMap;

public class TransitSystem {
	private HashMap<Integer,Stop> stops;
	private HashMap<Integer,Route> routes;
	private HashMap<Integer,Bus> buses;
	
	public TransitSystem() {
		stops = new HashMap<Integer, Stop>();
		buses = new HashMap<Integer, Bus>();
		routes = new HashMap<Integer, Route>();
	}
	
	public void makeStop(int uniqueId,String name, int riders, Double latitude, Double longitude) {
		stops.put(uniqueId, new Stop(uniqueId, name, riders, latitude, longitude));
		};
		
	public void makeRoute(int uniqueId,int number, String name) {
		routes.put(uniqueId, new Route(uniqueId,number,name));
	};
	
	public void makeBus(int uniqueId, int route, int currentLocation, int passengers, int passengerCapacity, int initialFuel, int fuelCapacity,int speed) {
		buses.put(uniqueId, new Bus(uniqueId, route, currentLocation, passengers, passengerCapacity, initialFuel, fuelCapacity, speed));
	};
	
	public void addStopToRoute(int routeId, int stopId) {
		(routes.get(routeId)).extendRoute(stopId);
	}
	
	public Stop getStop(int stopID) {
	    if (stops.containsKey(Integer.valueOf(stopID))) return stops.get(Integer.valueOf(stopID));
	    return null;
	  }
	  
	public Route getRoute(int routeID) {
	    if (routes.containsKey(Integer.valueOf(routeID))) return routes.get(Integer.valueOf(routeID));
	    return null;
	  }
	  
	public Bus getBus(int busID) {
	    if (buses.containsKey(Integer.valueOf(busID))) return buses.get(Integer.valueOf(busID));
	    return null;
	  }
	  
	public HashMap<Integer, Stop> getStops() {
		return stops;
	}

	public HashMap<Integer, Route> getRoutes() {
		return routes;
	}

	public HashMap<Integer, Bus> getBuses() {
		return buses;
	}
	}
